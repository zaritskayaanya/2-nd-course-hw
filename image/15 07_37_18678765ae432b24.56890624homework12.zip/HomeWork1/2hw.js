// Задание 1
let a = 10;
alert (a);
alert (a = 20);
// Задание 2
let iphone =  2007;
alert (iphone);
// Задание 3
let js = "Брендан Эйх";
alert (js);
// Задание 4
let x = 10;
let y = 2;
alert (x + y);
alert (x - y);
alert (x * y);
alert (x / y);
// Задание 5
alert (y ** 5);
// Задание 6
a = 9
b = 2
alert (a % b);
// Задание 7
let num = 1;
num = num + 5;
num = num - 3;
num = num * 7;
num = num / 3;
num = num + 1;
num = num - 1;
alert(num);
// Задание 8
let age = Number( prompt("Сколько вам лет?"));
alert (age);
// Задание 9
let user = {
    name: "Николай",    
    age: 22,            
    isAdmin: true };
    console.log(user);
// Задание 10
let yourName = prompt("Как вас зовут?");
alert (yourName); 
//Завершил домашку